# bro-sba-py model examples

This archive contains three Peewee model examples from the bro-sba-py project:

- `models/user.py` — user fields, sensitive-field handling, authentication settings, role configuration, and custom actions.
- `models/product.py` — choices, image uploads, search settings, and an inventory action.
- `models/cart.py` — foreign-key relationships and related display-field configuration.

## Use the examples

1. Extract this archive into your application so the three files are under `models/`.
2. Install Peewee and configure your application's database.
3. Update `from extensions import db` if your database object lives elsewhere. The cart model also imports `User` and `Product` from the `models` package.
4. Run `bro-py-admin --models-dir ./models --output-dir ./generated`, then `bro-py --models-dir ./models --output-dir ./generated`.
5. Review the generated project and configure database credentials before running it.

These files are examples to adapt. In particular, configure authentication and allowed roles for your own application before exposing it to users.
