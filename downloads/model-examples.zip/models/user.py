from peewee import BooleanField, CharField, Model

from extensions import db


class User(Model):
    class Meta:
        database = db

    name = CharField()
    email = CharField()
    role = CharField(null=True)
    password = CharField()
    is_verified = BooleanField(default=False)  # requis car auth_config()["email_verification"] != "none"

    # --- Métadonnées lues par scaffold.py --------------------------------

    @classmethod
    def insert_fields(cls):
        return {
            "name": {"required": True, "type": str},
            "email": {"required": True, "type": str},
            "role": {"required": False, "type": str, "default": "user"},
            "password": {"required": True, "type": str},
        }

    @classmethod
    def update_fields(cls):
        return {
            "name": {"required": False, "type": str},
            "email": {"required": False, "type": str},
            "role": {"required": False, "type": str},
        }

    @classmethod
    def search_fields(cls):
        return {
            "name": {"type": str, "operator": "like"},
            "role": {"type": str, "operator": "eq"},
        }

    @classmethod
    def custom_actions(cls):
        return {
            "freeze": {"method": "PATCH", "label": "Geler", "confirm": True},
            "change_role": {
                "params": {
                    "new_role": {"type": str, "required": True},
                },
                "route": "/users/<int:id>/change-role",
                "method": "POST",
                "label": "Changer le rôle",
                "generate": "full",
                "logic": {
                    "conditions": [
                        {
                            "if": {"field": "new_role", "operator": "not_in", "value": ["user", "admin", "moderator"]},
                            "then": {"error": "Rôle invalide"},
                        },
                    ],
                    "actions": [
                        {"set": {"field": "role", "value": "{new_role}"}},
                        {"save": True},
                    ],
                    "return": "instance",
                },
            },
            "reset_password": {
                "params": {
                    "new_password": {"type": str, "required": True},
                },
                "route": "/users/<int:id>/reset-password",
                "method": "POST",
                "label": "Réinitialiser le mot de passe",
            },
            "purge_inactive_sessions": {
                # Pas de route générée : appelée depuis ailleurs (une tâche
                # planifiée, un script, une autre API que je câble moi-même).
                "expose_api": False,
                "params": {
                    "days": {"type": int, "required": True},
                },
            },
        }

    @classmethod
    def admin_config(cls):
        return {
            "show_in_menu": True,
            "menu_label": "Utilisateurs",
            "list_fields": ["id", "name", "email", "role"],
            "actions": ["create", "update", "delete"],
        }

    @classmethod
    def sensitive_fields(cls):
        return ["password"]

    @classmethod
    def auth_config(cls):
        return {
            "username_field": "email",
            "password_field": "password",
            "role_field": "role",

            # Inscription publique : activable/désactivable, et rôle(s)
            # qu'une personne qui s'inscrit elle-même peut prendre — jamais
            # "admin" ici, l'admin doit être créé par un admin existant.
            "signup_enabled": True,
            "signup_allowed_roles": ["user"],
            "default_role": "user",

            # "none" | "signup" | "login" | "both"
            # Nécessite le champ booléen ci-dessous sur le modèle.
            "email_verification": "signup",
            "verified_field": "is_verified",

            # Qui peut se connecter au dashboard admin généré (session).
            "admin_dashboard_roles": ["admin"],

            # Où rediriger après connexion, selon le rôle (les rôles
            # peuvent être des strings ou des nombres — comparés en str()).
            "role_redirects": {
                "admin": "/dashboard-admin",
                "user": "/dashboard-user",
            },
            "default_redirect": "/dashboard",
        }
