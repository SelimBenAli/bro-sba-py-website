from peewee import BooleanField, CharField, FloatField, Model

from extensions import db


class Product(Model):
    class Meta:
        database = db

    name = CharField()
    category = CharField()
    price = FloatField()
    in_stock = BooleanField(default=True)
    photo = CharField(null=True)

    @classmethod
    def insert_fields(cls):
        return {
            "name": {"required": True, "type": str},
            "category": {"required": True, "type": str, "choices": ["furniture", "electronics", "clothing"]},
            "price": {"required": True, "type": float},
            "in_stock": {"required": False, "type": bool},
            "photo": {"required": False, "type": "image"},
        }

    @classmethod
    def update_fields(cls):
        return {
            "name": {"required": False, "type": str},
            "category": {"required": False, "type": str, "choices": ["furniture", "electronics", "clothing"]},
            "price": {"required": False, "type": float},
            "in_stock": {"required": False, "type": bool},
            "photo": {"required": False, "type": "image"},
        }

    @classmethod
    def search_fields(cls):
        return {
            "name": {"type": str, "operator": "like"},
            "category": {"type": str, "operator": "eq"},
        }

    @classmethod
    def custom_actions(cls):
        return {
            "mark_out_of_stock": {
                "route": "/products/<int:id>/mark-out-of-stock",
                "method": "POST",
                "label": "Marquer en rupture",
                "generate": "full",
                "logic": {
                    "actions": [
                        {"set": {"field": "in_stock", "value": False}},
                        {"save": True},
                    ],
                    "return": "instance",
                },
            },
        }

    @classmethod
    def admin_config(cls):
        return {
            "show_in_menu": True,
            "menu_label": "Produits",
            "list_fields": ["id", "name", "category", "price", "in_stock"],
            "actions": ["create", "update", "delete"],
        }
