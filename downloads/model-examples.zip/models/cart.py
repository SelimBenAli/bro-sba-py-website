from peewee import ForeignKeyField, IntegerField, Model

from extensions import db
from models.user import User
from models.product import Product


class Cart(Model):
    class Meta:
        database = db

    user = ForeignKeyField(User, backref="cart_items")
    product = ForeignKeyField(Product, backref="cart_items")
    quantity = IntegerField(default=1)

    @classmethod
    def insert_fields(cls):
        return {
            "user_id": {"required": True, "type": int},
            "product_id": {"required": True, "type": int},
            "quantity": {"required": True, "type": int},
        }

    @classmethod
    def update_fields(cls):
        return {
            "quantity": {"required": False, "type": int},
        }

    @classmethod
    def search_fields(cls):
        return {
            "user_id": {"type": int, "operator": "eq"},
            "product_id": {"type": int, "operator": "eq"},
        }

    @classmethod
    def admin_config(cls):
        return {
            "show_in_menu": False,
            "menu_label": "Paniers",
            "list_fields": ["id", "user_id", "product_id", "quantity"],
            "actions": ["update", "delete"],
            "foreign_keys": {
                "user_id": {"model": "user", "display_field": "name"},
                "product_id": {"model": "product", "display_field": "name"},
            },
        }
